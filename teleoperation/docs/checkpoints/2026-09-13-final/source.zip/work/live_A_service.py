"""Keep serial ownership across explicitly requested, locally tested actions."""
import importlib
import json
import signal
import time
from dataclasses import asdict
from pathlib import Path
from teleop.config import load
from teleop.hardware import Rig
from teleop.runtime import Events
import teleop.live_actions as actions
from teleop.awake import inhibit_sleep

inhibit_sleep()

def interrupt(*_):raise KeyboardInterrupt
signal.signal(signal.SIGTERM,interrupt)
control=Path('work/live_A_control.json')
events=Events('work/live_A_service.jsonl')
seen=None
try:
    with Rig(load('config/robot.json'),'A',allow_motion=True) as rig:
        rig.write_ids={12}
        while True:
            request=json.loads(control.read_text())
            if request.get('nonce')!=seen:
                seen=request.get('nonce')
                if request.get('action')=='shutdown':break
                if request.get('action')!='hold':
                    try:
                        # Only this fixed local handler module is reloaded, and only
                        # on a new explicit command. No code/module paths from JSON.
                        actions=importlib.reload(actions)
                        actions.execute_action(rig,load('config/robot.json'),events,request,str(control))
                    except Exception as exc:
                        events.emit({'schema':'teleop.live_action_failed.v1','unix_time':time.time(),'reason':str(exc)})
                        print('동작 중지: '+str(exc),flush=True)
            s=rig.sample()
            events.emit({'schema':'teleop.live_service_hold.v1','unix_time':time.time(),'motors':{i:asdict(v) for i,v in s.items()}})
            if any(v.hardware_error or v.temperature>=rig.config['safety']['max_temperature_c'] for v in s.values()):
                print('모터 상태 확인 필요. 새 동작을 시작하지 마세요.',flush=True)
                break
            time.sleep(.05)
except KeyboardInterrupt:
    print('서비스 종료. 토크는 해제하지 않았습니다.',flush=True)
except Exception as exc:
    events.emit({'schema':'teleop.live_service_failed.v1','unix_time':time.time(),'reason':str(exc)})
    print('추종 서비스 종료: '+str(exc),flush=True)
    raise
finally:
    events.close()
